# NixOS Migration Inventory

## Machine

- Hostname: t440s
- Distribution: Ubuntu 24.04.4 LTS
- Distribution family: debian
- Distribution version: 24.04
- Package manager: apt
- Collected: 2026-09-14T09:45:22-06:00

## Directory structure

### metadata/

Basic operating-system and machine information.

### hardware/

CPU, RAM, PCI, USB, GPU and kernel-module information.

### storage/

Disks, filesystems, mounts, LUKS, LVM, RAID, ZFS and Btrfs.

### network/

Interfaces, routes, DNS, firewall and listening ports.

### packages/

Installed packages and package-manager information.

### services/

Systemd services, timers, sockets and scheduled jobs.

### users/

Users, groups, shells and sudo configuration.

### configuration/

Important configuration references and custom software locations.

### logs/

Diagnostic information.

## Important

This inventory is intended as input for a NixOS migration.

Do not blindly convert every package to NixOS.

The preferred migration strategy is:

1. Identify what the machine actually does.
2. Identify the services it provides.
3. Identify hardware-specific requirements.
4. Map services to NixOS modules.
5. Map packages to nixpkgs packages.
6. Move user-specific configuration to Home Manager where appropriate.
7. Handle secrets separately with sops-nix or agenix.
8. Test the resulting configuration in a VM.
9. Deploy to the physical machine.

Review logs/sensitive-file-review.txt before committing the inventory
to a Git repository.
